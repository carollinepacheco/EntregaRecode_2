package model;

public class Pacotes {

	private int id;
	private String destino;
	private String hospedagem;
	private String diarias;
	private double preco;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDestino() {
		return destino;
	}
	public void setDestino(String destino) {
		this.destino = destino;
	}
	public String getHospedagem() {
		return hospedagem;
	}
	public void setHospedagem(String hospedagem) {
		this.hospedagem = hospedagem;
	}
	public String getDiarias() {
		return diarias;
	}
	public void setDiarias(String diarias) {
		this.diarias = diarias;
	}
	public double getPreco() {
		return preco;
	}
	public void setPreco(double preco) {
		this.preco = preco;
	}
}
